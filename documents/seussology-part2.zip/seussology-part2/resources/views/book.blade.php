@extends('layouts.seussology')

@section('title', 'Book Details')


@section('main')
<main id="main" class="details">
    <div class="details-controls">
    <a href="/edit" class="details-control"><i class="far fa-edit"></i></a>
    <a href="/delete" class="details-control"><i class="far fa-trash-alt"></i></a>
    </div>
    <div class="details-image">
        <img src="http://www.seussville.com/media/assets/all-book-covers/1.jpg" alt="And to Think That I Saw It on Mulberry Street">
    </div>
    <div>
        <h2 class="details-title">And to Think That I Saw It on Mulberry Street</h2>
        <p>Marco watches the sight and sounds of people and vehicles traveling along Mulberry Street and dreams up an elaborate story to tell to his father at the end of his walk.</p>
        <p>Published: 1937<br>
        Number of Pages: 40</p>
        <blockquote class="details-quote">
            <p>Stop telling such outlandish tales. Stop turning minnows into whales.</p>
        </blockquote>

        <blockquote class="details-quote">
            <p>For I had a story that no one could beat! And to think that I saw it on Mulberry Street!</p>
        </blockquote>
    </div>
</main>
@endsection
