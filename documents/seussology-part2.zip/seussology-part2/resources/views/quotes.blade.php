@extends('layouts.seussology')

@section('title', 'Quotes')


@section('main')
<main id="main" class="quotes">
        <div class="quote">
          <p class="quote-text">Stop telling such outlandish tales. Stop turning minnows into whales.</p>
          <p class="quote-citation">from <a href="details.html">And to Think That I Saw It on Mulberry Street</a></p>
        </div>
        <div class="quote">
          <p class="quote-text">For I had a story that no one could beat! And to think that I saw it on Mulberry Street!</p>
          <p class="quote-citation">from <a href="details.html">And to Think That I Saw It on Mulberry Street</a></p>
        </div>
        <div class="quote">
          <p class="quote-text">Lorem ipsum dolor sit amet consectetur adipisicing elit. Non dolorum distinctio in error eligendi repellendus.</p>
          <p class="quote-citation">from <a>Book Title</a></p>
        </div>
        <div class="quote">
          <p class="quote-text">Lorem ipsum dolor sit amet consectetur adipisicing elit. Non dolorum distinctio in error eligendi repellendus.</p>
          <p class="quote-citation">from <a>Book Title</a></p>
        </div>
        <div class="quote">
          <p class="quote-text">Lorem ipsum dolor sit amet consectetur adipisicing elit. Non dolorum distinctio in error eligendi repellendus.</p>
          <p class="quote-citation">from <a>Book Title</a></p>
        </div>
        <div class="quote">
          <p class="quote-text">Lorem ipsum dolor sit amet consectetur adipisicing elit. Non dolorum distinctio in error eligendi repellendus.</p>
          <p class="quote-citation">from <a>Book Title</a></p>
        </div>
    </main>
@endsection
