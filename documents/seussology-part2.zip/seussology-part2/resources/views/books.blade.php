@extends('layouts.seussology')

@section('title', 'Books')

@section('header')
    <form class="search">
        <input type="search" name="search" class="form-input" placeholder="Search Books">
    </form>
@endsection


@section('main')
    <main id="main" class="books">
      <div class="book">
        <a class="book-image" href="/book">
          <img src="http://www.seussville.com/media/assets/all-book-covers/1.jpg" alt="And to Think That I Saw It on Mulberry Street">
        </a>
      </div>
    </main>
@endsection
