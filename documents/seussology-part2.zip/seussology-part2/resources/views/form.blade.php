@extends('layouts.seussology')

@section('title', $title)


@section('main')
<main id="main" class="container">
    <form class="form">
        <div class="form-group title">
            <label class="form-label">Title</label>
            <input class="form-input" type="text" name="title">
        </div>

        <div class="form-group category">
            <label class="form-label">Category</label>
            <select class="form-input">
                <option></option>
                <option value="1">Beginner Books</option>
                <option value="2">Big Books</option>
                <option value="3">Short Stories</option>
            </select>
        </div>

        <div class="form-group year">
            <label class="form-label">Published Year</label>
            <input class="form-input" type="text" maxlength="4" name="year">
        </div>

        <div class="form-group pages">
            <label class="form-label">Number of Pages</label>
            <input class="form-input" type="number" name="pages">
        </div>

        <div class="form-group image">
            <label class="form-label">Cover Image</label>
            <input class="form-input" type="text" name="image">
        </div>


        <div class="form-group description">
        <label class="form-label">Description</label>
        <textarea class="form-input" name="description"></textarea>
        </div>

        <div class="form-group">
            <button class="button">Submit</button>
        </div>
    </form>

</main>
@endsection
