<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/{books?}/{id?}', function () {
    return view('spa');
});

// Route::get('/', 'BooksController@index');

Route::get('/book/{id}', 'BooksController@show');

Route::get('/new', 'BooksController@new');

Route::post('/new', 'BooksController@store');

Route::get('/edit/{id}', 'BooksController@edit');

Route::post('/edit/{book}', 'BooksController@update');

Route::get('/delete/{id}', 'BooksController@delete');

Route::get('/quotes', 'QuotesController@index');
