@extends('layouts.seussology')

@section('title', $title)


@section('main')
<main id="main" class="container">
    <form class="form" method="post">
        {{ csrf_field() }}
        <div class="form-group title">
            <label class="form-label">Title</label>
            <input class="form-input" type="text" name="book_title" value="@isset($book['book_title']){{ $book['book_title'] }}@endisset">
        </div>

        <div class="form-group category">
            <label class="form-label">Category</label>
            <select class="form-input" name="category_id">
                <option></option>
                @foreach ($categories as $category)
                    <option value="{{ $category['id'] }}"
                        @isset($bookCategory)
                            @if ($category['id'] === $bookCategory['id'])
                            selected="selected"
                            @endif
                        @endisset
                    >{{ $category['category_name'] }}</option>
                @endforeach
            </select>
        </div>

        <div class="form-group year">
            <label class="form-label">Published Year</label>
            <input class="form-input" type="text" maxlength="4" name="book_year" value="@isset($book['book_year']){{ $book['book_year'] }}@endisset">
        </div>

        <div class="form-group pages">
            <label class="form-label">Number of Pages</label>
            <input class="form-input" type="number" name="book_pages" value="@isset($book['book_pages']){{ $book['book_pages'] }}@endisset">
        </div>

        <div class="form-group image">
            <label class="form-label">Cover Image</label>
            <input class="form-input" type="text" name="book_image" value="@isset($book['book_image']){{ $book['book_image'] }}@endisset">
        </div>


        <div class="form-group description">
        <label class="form-label">Description</label>
        <textarea class="form-input" name="book_description">@isset($book['book_description']){{ $book['book_description'] }}@endisset</textarea>
        </div>

        <div class="form-group">
            <button class="button">Submit</button>
        </div>
    </form>

</main>
@endsection
