<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Seussology SPA</title>
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.4.2/css/all.css" integrity="sha384-/rXc/GQVaYpyDdyxK+ecHPVYJSN9bmVFBvjA/9eOB+pb3F2w2N6fc5qB9Ew5yIns" crossorigin="anonymous">
    <link rel="stylesheet" href="/css/seussology.css">

</head>
<body>
    <nav id="nav" class="nav">
      <a href="/quotes" class="nav-link">Quotes</a>
      <a href="/" class="nav-link">
          <img id="logo" class="nav-image" src="/images/seussology-logo.svg" alt="Seussology">
      </a>
      <a href="/books/new/" class="nav-link ">New Book</a>
    </nav>
    <header id="header" class="header">
        <h1 id="title" class="header-title">Books</h1>
    </header>
    <main id="main" class="books"></main>


    <script src="/js/seussology.js"></script>
</body>
</html>
