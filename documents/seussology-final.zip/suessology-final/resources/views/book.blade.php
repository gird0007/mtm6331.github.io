@extends('layouts.seussology')

@section('title', 'Book Details')


@section('main')
<main id="main" class="details">
    <div class="details-controls">
    <a href="/edit/{{ $book['id'] }}" class="details-control"><i class="far fa-edit"></i></a>
    <a href="/delete/{{ $book['id'] }}" class="details-control"><i class="far fa-trash-alt"></i></a>
    </div>
    <div class="details-image">
        <img src="{{ $book['book_image'] }}" alt="{{ $book['book_title'] }}">
    </div>
    <div>
        <h2 class="details-title">{{ $book['book_title'] }}</h2>
        <p>{{ $book['book_description'] }}</p>
        <p>Published: {{ $book['book_year'] }}<br>
        Number of Pages: {{ $book['book_pages'] }}</p>
        @foreach ($quotes as $quote)
        <blockquote class="details-quote">
            <p>{{ $quote['quote'] }}</p>
        </blockquote>
        @endforeach
    </div>
</main>
@endsection
