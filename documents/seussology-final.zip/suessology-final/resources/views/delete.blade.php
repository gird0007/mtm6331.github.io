@extends('layouts.seussology')

@section('title', "The book, {$title}, has been deleted")
