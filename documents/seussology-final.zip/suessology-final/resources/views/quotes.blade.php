@extends('layouts.seussology')

@section('title', 'Quotes')


@section('main')
<main id="main" class="quotes">
    @foreach ($quotes as $quote)
        <div class="quote">
          <p class="quote-text">{{ $quote['quote'] }}</p>
          <p class="quote-citation">from <a href="/book/{{ $quote['book']['id'] }}">{{ $quote['book']['book_title'] }}</a></p>
        </div>
    @endforeach
</main>
@endsection
