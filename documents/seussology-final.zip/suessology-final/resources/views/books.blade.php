@extends('layouts.seussology')

@section('title', 'Books')

@section('header')
    <form class="search">
        <input type="search" name="search" class="form-input" placeholder="Search Books">
    </form>
@endsection


@section('main')
    <main id="main" class="books">
        @foreach ($books as $book)
            <div class="book">
                <a class="book-image" href="/book/{{ $book['id'] }}">
                <img src="{{ $book['book_image'] }}" alt="{{ $book['book_title'] }}">
                </a>
            </div>
        @endforeach
    </main>
@endsection
