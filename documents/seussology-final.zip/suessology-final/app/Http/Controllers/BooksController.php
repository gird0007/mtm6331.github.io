<?php

namespace App\Http\Controllers;

use App\Book;
use App\Category;

use Illuminate\Http\Request;

class BooksController extends Controller
{
    public function index ()
    {
        $books = Book::all();
        // return view('books', ['books' => $books]);
        return response()->json($books);
    }

    public function show ($id)
    {
        $book = Book::find($id);
        $quotes = Book::find($id)->quotes;
        $book['quotes'] = $quotes;
        //return view('book', ['book' => $book, 'quotes' => $quotes]);
        return response()->json($book);
    }

    public function new ()
    {
        $categories = Category::all();
        return view('form', ['title' => 'Add Book', 'categories' => $categories]);
    }

    public function store (Request $request)
    {
        $book = Book::create($request->all());
        // return redirect("/edit/{$book['id']}");
        return response()->json($book, 201);
    }

    public function edit ($id)
    {
        $book = Book::find($id);
        $category = Book::find($id)->category;
        $categories = Category::all();
        return view('form', [
            'title' => 'Edit Book',
            'book' => $book,
            'bookCategory' => $category,
            'categories' => $categories
        ]);
    }

    public function update (Request $request, Book $book)
    {
        $book->update($request->all());
        //return $this->edit($id);
        return response()->json($book, 200);
    }

    public function delete ($id)
    {
        $book = Book::find($id);
        $book->delete();

        // return view('delete', ['title' => $book['book_title']]);
        return response()->json(null, 204);
    }
 }
