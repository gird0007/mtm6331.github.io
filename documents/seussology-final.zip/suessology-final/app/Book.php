<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Book extends Model
{
    protected $fillable = [
        'book_title',
        'book_year',
        'book_pages',
        'book_image',
        'book_description',
        'category_id'
    ];

    public $timestamps = false;

    /**
     * Get quotes for book
     */
    public function quotes()
    {
        return $this->hasMany('App\Quote');
    }

    public function category()
    {
        return $this->belongsTo('App\Category');
    }
}
