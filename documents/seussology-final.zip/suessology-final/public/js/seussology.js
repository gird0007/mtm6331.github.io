const main = document.getElementById('main')
const title = document.getElementById('title')
const routes = {
  '/': getBooks,
  '/books/': getBook,
  '/books/new/': getForm,
  '/books/edit/': getForm
}

const templates = {
  'books': function (books) {
    main.innerHTML = books.map(book => `
      <div class="book">
        <a class="book-image" data-id="${book['id']}" href="/books/#${book['id']}">
          <img src="${book['book_image']}" alt="${book['book_title']}">
        </a>
      </div>`).join('')
  },
  'book': function (book) {
    main.innerHTML = `
      <div class="details-controls">
        <a href="/books/edit/#${book['id']}" class="details-control"><i class="far fa-edit"></i></a>
        <a class="details-control" data-action="delete"><i class="far fa-trash-alt"></i></a>
      </div>
      <div class="details-image">
          <img src="${book['book_image']}" alt="${book['book_title']}">
      </div>
      <div>
        <h2 class="details-title">${book['book_title']}</h2>
        <p>${book['book_description']}</p>
        <p>Published: ${book['book_year']}<br>
        Number of Pages: ${book['book_pages']}</p>
        ${book.quotes.map(quote => `
          <blockquote class="details-quote">
              <p>${quote['quote']}</p>
          </blockquote>`).join('')}
      </div>`
  },
  'form': function (book) {
    const categories = [
      '',
      'Beginner Books',
      'Big Books',
      'Short Stories'
    ]

    main.innerHTML = `
      <form id="form" class="form" enctype="multipart/form-data">
        <div class="form-group title">
          <label class="form-label">Title</label>
          <input id="book_title" class="form-input" type="text" name="title" value="${book['book_title']}">
        </div>

        <div class="form-group category">
          <label class="form-label">Category</label>
          <select id="category_id" class="form-input">
            ${categories.map((cat, index) => `<option value="${index}" ${(index === book['category_id'] ? 'selected = "selected"' : '')}>${cat}</option>`).join('')}
          </select>
        </div>

        <div class="form-group year">
            <label class="form-label">Published Year</label>
            <input id="book_year" class="form-input" type="text" maxlength="4" name="year" value="${book['book_year']}">
        </div>

        <div class="form-group pages">
            <label class="form-label">Number of Pages</label>
            <input id="book_pages" class="form-input" type="number" name="pages" value="${book['book_pages']}">
        </div>

        <div class="form-group image">
            <label class="form-label">Cover Image</label>
            <input id="book_image" class="form-input" type="text" name="image" value="${book['book_image']}">
        </div>


        <div class="form-group description">
          <label class="form-label">Description</label>
          <textarea id="book_description" class="form-input" name="description">${book['book_description']}</textarea>
        </div>

        <div class="form-group">
          <button class="button">Submit</button>
        </div>
      </form>`
  }
}

function getBooks () {
  fetch('http://mtm6331-laravel.local/api/books')
    .then(function (response) {
      return response.json()
    })
    .then(function (books) {
      title.textContent = 'Books'
      main.className = 'books'
      templates.books(books)
    })
}

function getBook () {
  const index = location.hash.substr(1)

  fetch(`http://mtm6331-laravel.local/api/books/${index}`)
    .then(function (response) {
      return response.json()
    })
    .then(function (book) {
      main.className = 'details'
      title.textContent = 'Book Details'
      templates.book(book)
    })
}

function getForm () {
  const index = location.hash.substr(1)

  if (index) {
    fetch(`http://mtm6331-laravel.local/api/books/${index}`)
      .then(function (response) {
        return response.json()
      })
      .then(function (book) {
        main.className = 'container'
        title.textContent = 'Edit Book'
        templates.form(book)
      })
  } else {
    const book = {
      'book_title': '',
      'category_id': '',
      'book_year': '',
      'book_pages': '',
      'book_image': '',
      'book_description': ''
    }

    main.className = 'container'
    title.textContent = 'New Book'
    templates.form(book)
  }
}

function setBook (data) {
  const index = (location.hash) ? `/${location.hash.substr(1)}` : ''
  const method = (index) ? 'put' : 'post'

  fetch(`http://mtm6331-laravel.local/api/books${index}`, {
    method: method,
    headers: {
      'Content-Type': 'application/json; charset=utf-8'
    },
    body: JSON.stringify(data)
  })
    .then(function (response) {
      return response.json()
    })
    .then(function (book) {
      history.pushState(null, 'Suessology', `/books/#${book['id']}`)
      routes[location.pathname]()
    })
}

function removeBook () {
  const index = location.hash.substr(1)

  if (index) {
    fetch(`http://mtm6331-laravel.local/api/books/${index}`, {
      method: 'delete'
    })
      .then(function () {
        history.pushState(null, 'Suessology', '/')
        routes[location.pathname]()
      })
  }
}

document.addEventListener('click', function (e) {
  e.preventDefault()
  const link = e.target.closest('a')
  if (link && link.href) {
    history.pushState(null, 'Seussology', link.href)
    routes[location.pathname]()
  } else if (e.target.classList.contains('button')) {
    const data = {
      'book_title': document.getElementById('book_title').value,
      'category_id': document.getElementById('category_id').value,
      'book_year': document.getElementById('book_year').value,
      'book_pages': document.getElementById('book_pages').value,
      'book_image': document.getElementById('book_image').value,
      'book_description': document.getElementById('book_description').value
    }

    setBook(data)
  } else {
    const link = e.target.closest('[data-action]')
    if (link.dataset.action === 'delete') {
      removeBook()
    }
  }
})

routes[location.pathname]()
